class Chat {
  String title;
  int index;

  Chat({
    this.title,
    this.index,
  });
}



List<Chat> ChatMessage = <Chat>[
  Chat(title: "Exercitation veniam consequat sunt nostrud amet.", index: 0),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.",
      index: 1),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
      index: 0),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
      index: 0),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
      index: 1),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
      index: 1),
  Chat(
      title:
      "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
      index: 1),
];

List<Chat> Suggetionlist = <Chat>[
  Chat(
    title:
        "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.",
  ),
  Chat(
    title:
        "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
  ),
  Chat(
    title:
    "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.",
  ),
  Chat(
    title:
    "Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.",
  ),
  Chat(
    title:
    "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
  ),
  Chat(
    title:
    "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.",
  ),
  Chat(
    title:
    "Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.",
  ),
];


